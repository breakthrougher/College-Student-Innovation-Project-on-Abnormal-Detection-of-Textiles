ALL_CATEGORY = [
    "capsule",
    "metal_nut",
    "pill",
    "toothbrush",
    "transistor",
    "wood",
    "zipper",
    "cable",
    "bottle",
    "grid",
    "hazelnut",
    "leather",
    "tile",
    "carpet",
    "screw",
]
RESIZE_SHAPE = [256, 256]  # width * height
NORMALIZE_MEAN = [0.485, 0.456, 0.406]
NORMALIZE_STD = [0.229, 0.224, 0.225]
